import PersonalDataClient from "./PersonalDataClient"

export const metadata = {
  title: 'Согласие на обработку персональных данных - ЖК "Гений"',
  description: "Согласие на обработку персональных данных ЖК Гений",
}

export default function PersonalDataConsent() {
  return <PersonalDataClient />
}
