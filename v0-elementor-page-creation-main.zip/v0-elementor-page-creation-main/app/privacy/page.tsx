import PrivacyPolicyClient from "./PrivacyPolicyClient"

export const metadata = {
  title: "Политика в отношении обработки персональных данных - Domfy",
  description: "Политика в отношении обработки персональных данных агентства недвижимости Domfy",
}

export default function PrivacyPolicy() {
  return <PrivacyPolicyClient />
}
